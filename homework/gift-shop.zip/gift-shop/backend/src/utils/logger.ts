class Logger {
    info(message: string) {
      console.log(`[INFO] ${message}`);
    }
  }
  
  export default new Logger();
  