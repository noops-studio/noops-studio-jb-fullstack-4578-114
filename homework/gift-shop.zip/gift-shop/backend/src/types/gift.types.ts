export interface Gift {
    id: number;
    targetId: number;
    name: string;
    description: string;
    price: number;
    discount: number;
  }
  