export interface Target {
    id: number;
    type: string;
  }
  